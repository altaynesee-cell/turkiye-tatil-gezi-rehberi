package com.altay.turkiyetatil

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.net.URLEncoder

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { App(this) } }
    }
}

@Composable
private fun App(activity:ComponentActivity) {
    var province by remember { mutableStateOf("Bursa") }
    var district by remember { mutableStateOf("") }
    var menu by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf("Lezzet") }
    var foodKey by remember { mutableStateOf("Köfte") }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Lezzet türünü seç.") }
    var results by remember { mutableStateOf<List<SearchResult>>(emptyList()) }
    var featured by remember { mutableStateOf<SearchResult?>(null) }

    fun doNormalSearch(category:String) {
        if(loading) return
        selected=category
        featured=null
        loading=true
        results=emptyList()
        message="$province ${district.ifBlank { "" }} için aranıyor…"
        Thread {
            try {
                val r=SearchEngine.search(province,district,category)
                activity.runOnUiThread {
                    results=r
                    message=if(r.isEmpty()) "Bu bölgede adlandırılmış sonuç bulunamadı."
                    else "${r.size} tekil sonuç bulundu."
                    loading=false
                }
            } catch(e:Exception) {
                activity.runOnUiThread {
                    message=e.message ?: "Arama sırasında hata oluştu."
                    loading=false
                }
            }
        }.start()
    }

    fun doFoodSearch(key:String) {
        if(loading) return
        selected="Lezzet"
        foodKey=key
        featured=null
        results=emptyList()
        loading=true
        message="$province ${district.ifBlank { "" }} • $key aranıyor…"
        Thread {
            try {
                val b=SearchEngine.searchFood(province,district,key)
                activity.runOnUiThread {
                    featured=b.featured
                    results=b.alternatives
                    message=when {
                        b.featured!=null -> "1 köklü/meşhur ana öneri + ${b.alternatives.size} yerel alternatif."
                        b.alternatives.isNotEmpty() -> "Doğrulanmış köklü/meşhur kayıt yok; ${b.alternatives.size} zincir olmayan yerel alternatif var."
                        else -> "Bu bölgede $key için uygun yer bulunamadı."
                    }
                    loading=false
                }
            } catch(e:Exception) {
                activity.runOnUiThread {
                    message=e.message ?: "Arama sırasında hata oluştu."
                    loading=false
                }
            }
        }.start()
    }

    fun route(r:SearchResult) {
        val label=URLEncoder.encode(r.name,"UTF-8")
        val uri=Uri.parse("geo:${r.lat},${r.lon}?q=${r.lat},${r.lon}($label)")
        activity.startActivity(Intent(Intent.ACTION_VIEW,uri))
    }

    Surface(Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize().padding(horizontal=14.dp, vertical=10.dp),
            verticalArrangement=Arrangement.spacedBy(9.dp)
        ) {
            Text("Türkiye Tatil Gezi Rehberi",fontSize=26.sp,fontWeight=FontWeight.Bold)
            Text("V2.2 • Yerel lezzet",fontWeight=FontWeight.SemiBold)

            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                Box(Modifier.weight(1f)) {
                    OutlinedButton(onClick={menu=true},modifier=Modifier.fillMaxWidth()) {
                        Text("📍 $province")
                    }
                    DropdownMenu(expanded=menu,onDismissRequest={menu=false}) {
                        Provinces.all.forEach { p ->
                            DropdownMenuItem(
                                text={Text(p)},
                                onClick={ province=p; district=""; menu=false; results=emptyList(); featured=null }
                            )
                        }
                    }
                }
                OutlinedTextField(
                    value=district,
                    onValueChange={district=it},
                    label={Text("İlçe (isteğe bağlı)")},
                    singleLine=true,
                    modifier=Modifier.weight(1f)
                )
            }

            Row(horizontalArrangement=Arrangement.spacedBy(7.dp),modifier=Modifier.fillMaxWidth()) {
                Button(
                    onClick={ selected="Lezzet"; results=emptyList(); featured=null; message="Lezzet türünü seç." },
                    modifier=Modifier.weight(1f)
                ) { Text("🍽️ Lezzet") }
                Button(onClick={doNormalSearch("Deniz")},modifier=Modifier.weight(1f),enabled=!loading) {
                    Text("🌊 Deniz")
                }
            }
            Row(horizontalArrangement=Arrangement.spacedBy(7.dp),modifier=Modifier.fillMaxWidth()) {
                Button(onClick={doNormalSearch("Keşfet")},modifier=Modifier.weight(1f),enabled=!loading) {
                    Text("🏛️ Keşfet")
                }
                Button(onClick={doNormalSearch("Konak")},modifier=Modifier.weight(1f),enabled=!loading) {
                    Text("🛏️ Konak")
                }
            }

            if(selected=="Lezzet") {
                Text("Ne yemek istiyorsun?",fontWeight=FontWeight.Bold)
                FoodRules.categories.chunked(2).forEach { row ->
                    Row(horizontalArrangement=Arrangement.spacedBy(7.dp),modifier=Modifier.fillMaxWidth()) {
                        row.forEach { key ->
                            OutlinedButton(
                                onClick={doFoodSearch(key)},
                                modifier=Modifier.weight(1f),
                                enabled=!loading
                            ) { Text(if(key==foodKey) "✓ $key" else key) }
                        }
                        if(row.size==1) Spacer(Modifier.weight(1f))
                    }
                }
            }

            if(loading) LinearProgressIndicator(Modifier.fillMaxWidth())
            Text(message,style=MaterialTheme.typography.bodyMedium)

            LazyColumn(
                modifier=Modifier.weight(1f),
                verticalArrangement=Arrangement.spacedBy(10.dp)
            ) {
                featured?.let { r ->
                    item(key="featured-${r.id}") {
                        Card(shape=RoundedCornerShape(18.dp),modifier=Modifier.fillMaxWidth()) {
                            Column(
                                Modifier.padding(15.dp),
                                verticalArrangement=Arrangement.spacedBy(6.dp)
                            ) {
                                Text("⭐ KÖKLÜ / MEŞHUR ANA ÖNERİ",fontWeight=FontWeight.Bold)
                                Text(r.name,fontSize=21.sp,fontWeight=FontWeight.Bold)
                                Text("${r.district.ifBlank { r.province }}, ${r.province}")
                                r.startYear?.let { Text("🕰 Kuruluş: $it",fontWeight=FontWeight.SemiBold) }
                                if(r.heritageSource.isNotBlank()) {
                                    Text("Doğrulama: ${r.heritageSource}",style=MaterialTheme.typography.bodySmall)
                                }
                                Button(onClick={route(r)},modifier=Modifier.fillMaxWidth()) {
                                    Text("🧭 YOL TARİFİ")
                                }
                            }
                        }
                    }
                    if(results.isNotEmpty()) {
                        item { Text("Alternatif yerel seçenekler",fontWeight=FontWeight.Bold,fontSize=18.sp) }
                    }
                }

                items(results,key={it.id}) { r ->
                    Card(shape=RoundedCornerShape(18.dp),modifier=Modifier.fillMaxWidth()) {
                        Column(
                            Modifier.padding(15.dp),
                            verticalArrangement=Arrangement.spacedBy(6.dp)
                        ) {
                            Text(r.name,fontSize=20.sp,fontWeight=FontWeight.Bold)
                            Text("${r.district.ifBlank { r.province }}, ${r.province}")
                            Text(r.detail,fontWeight=FontWeight.SemiBold)
                            r.startYear?.let { Text("🕰 OSM kuruluş kaydı: $it") }
                            Text("Yerel alternatif • zincir sonuçlar filtrelendi",style=MaterialTheme.typography.bodySmall)
                            Button(onClick={route(r)},modifier=Modifier.fillMaxWidth()) {
                                Text("🧭 YOL TARİFİ")
                            }
                        }
                    }
                }
            }

            Text("© OpenStreetMap katkıda bulunanlar",style=MaterialTheme.typography.labelSmall)
        }
    }
}
