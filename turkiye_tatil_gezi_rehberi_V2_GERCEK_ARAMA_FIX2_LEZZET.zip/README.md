# Türkiye Tatil Gezi Rehberi — V2.2 Yerel Lezzet

Lezzet artık genel restoran listesi değildir.

Alt kategoriler:
- Köfte
- Kebap
- Ciğer
- Sulu Yemek
- Esnaf Lokantası
- Balık
- Kahvaltı
- Tavuk

Davranış:
- Burger King, McDonald's, KFC, Popeyes, Köfteci Yusuf, Baydöner vb. zincirler Lezzet sonuçlarından filtrelenir.
- Her aramada en fazla 1 adet doğrulanmış "Köklü / Meşhur Ana Öneri" gösterilir.
- Ana öneri için kaynaklı curated kayıt gerekir; kaynak yoksa uygulama "köklü/meşhur" iddiası uydurmaz.
- Altında en fazla 8 zincir olmayan yerel alternatif gösterilir.
- OSM start_date varsa kuruluş yılı alternatif kartında gösterilir.
- Bursa/Köfte için kaynaklı başlangıç kayıtları: Besler 1893, Rodop 1946.
- Yol Tarifi korunur.
- 429 için çoklu Overpass fallback korunur.
