package com.altay.turkiyetatil

data class VerifiedPlace(
    val id:String,
    val canonicalId:String,
    val province:String,
    val district:String,
    val section:String,
    val subcategory:String="",
    val name:String,
    val aliases:List<String> = emptyList(),
    val foundedYear:Int? = null,
    val featured:Boolean = false,
    val summary:String,
    val address:String,
    val sourceLabel:String,
    val sourceUrl:String
)

data class VerifiedBundle(
    val featured:VerifiedPlace?,
    val alternatives:List<VerifiedPlace>
)

object VerifiedCatalog {
    val foodCategories = listOf(
        "Köfte","Kebap","Ciğer","Sulu Yemek",
        "Esnaf Lokantası","Balık","Kahvaltı","Tavuk"
    )

    private val forbiddenFoodNames = listOf(
        "köfteci yusuf","kofteci yusuf","burger king","mcdonald",
        "kfc","popeyes","domino","pizza hut","starbucks","subway"
    )

    val all:List<VerifiedPlace> = listOf(
        // -----------------------------------------------------------
        // BURSA — LEZZET / KÖFTE
        // -----------------------------------------------------------
        VerifiedPlace(
            id="bursa-kofte-besler-1893",
            canonicalId="besler-inegol-koftecisi",
            province="Bursa",
            district="İnegöl",
            section="Lezzet",
            subcategory="Köfte",
            name="Besler İnegöl Köftecisi",
            foundedYear=1893,
            featured=true,
            summary="Bursa Büyükşehir Belediyesi'nin Rota Bursa kaydında köftenin 1893'te Mustafa Efendi tarafından İnegöl'de satılmaya başlandığı ve kuşaktan kuşağa sürdüğü belirtiliyor.",
            address="Belediye Cad. No:57, İshakpaşa Camii civarı, İnegöl/Bursa",
            sourceLabel="Rota Bursa • Bursa Büyükşehir Belediyesi",
            sourceUrl="https://rota.bursa.com.tr/mekanlar/besler-inegol-koftecisi-1893-776"
        ),
        VerifiedPlace(
            id="bursa-kofte-sefa-1940",
            canonicalId="sefa-inegol-koftecisi",
            province="Bursa",
            district="İnegöl",
            section="Lezzet",
            subcategory="Köfte",
            name="Sefa İnegöl Köftecisi",
            foundedYear=1940,
            summary="Rota Bursa kaydı işletmenin 1940 yılında Hacı Asım Çelik tarafından kurulduğunu ve üç kuşaktır İnegöl köftesi hazırladığını belirtiyor.",
            address="Orhaniye, Ankara Cd. No:29, İnegöl/Bursa",
            sourceLabel="Rota Bursa • Bursa Büyükşehir Belediyesi",
            sourceUrl="https://rota.bursa.com.tr/mekanlar/sefa-inegol-koftecisi-1940-779"
        ),
        VerifiedPlace(
            id="bursa-kofte-rodop-1946",
            canonicalId="rodop-koftecisi",
            province="Bursa",
            district="Osmangazi",
            section="Lezzet",
            subcategory="Köfte",
            name="Rodop Köftecisi",
            foundedYear=1946,
            summary="İşletmenin resmi tarihçesinde Halil Şensoylu'nun 1946'da Setbaşı'nda işe başladığı ve ailenin üçüncü nesil olarak geleneği sürdürdüğü anlatılıyor.",
            address="Çekirge, Osmangazi/Bursa",
            sourceLabel="Rodop Köftecisi • Resmî tarihçe",
            sourceUrl="https://rodopkoftecisi.com.tr/tarihce/"
        ),
        VerifiedPlace(
            id="bursa-kofte-omur-1965",
            canonicalId="omur-koftecisi",
            province="Bursa",
            district="Osmangazi",
            section="Lezzet",
            subcategory="Köfte",
            name="Ömür Köftecisi",
            foundedYear=1965,
            summary="Rota Bursa kaydı Ömür Köftecisi'nin 1965'te Enver Yavaş tarafından kurulduğunu ve yarım asrı aşan süredir hizmet verdiğini belirtiyor.",
            address="Şehreküstü, Ulucami Cd. No:9, Osmangazi/Bursa",
            sourceLabel="Rota Bursa • Bursa Büyükşehir Belediyesi",
            sourceUrl="https://rota.bursa.com.tr/mekanlar/omur-koftecisi-1965-778"
        ),

        // -----------------------------------------------------------
        // BURSA — LEZZET / KEBAP
        // -----------------------------------------------------------
        VerifiedPlace(
            id="bursa-kebap-iskender-1867",
            canonicalId="kebapci-iskender",
            province="Bursa",
            district="Osmangazi",
            section="Lezzet",
            subcategory="Kebap",
            name="Kebapçı İSKENDER®",
            foundedYear=1867,
            featured=true,
            summary="İşletmenin resmî tarihçesinde İskender Efendi'nin ilk dükkânını 1867'de Bursa Kayhan Çarşısı'nda açtığı belirtiliyor.",
            address="İskender Efendi Konağı, Erdem Saker Botanik Parkı No:1, Osmangazi/Bursa",
            sourceLabel="Kebapçı İSKENDER® • Resmî tarihçe",
            sourceUrl="https://iskender.com/tarihce/"
        ),
        VerifiedPlace(
            id="bursa-kebap-yeni-hacibey-1970",
            canonicalId="yeni-hacibey-kebapcisi",
            province="Bursa",
            district="Osmangazi",
            section="Lezzet",
            subcategory="Kebap",
            name="Yeni Hacıbey Kebapçısı",
            foundedYear=1970,
            summary="Bursa Büyükşehir Belediyesi Rota Bursa kataloğunda 1970 kuruluş yılıyla Kayhan Çarşısı'nın köklü kebap duraklarından biri olarak yer alıyor.",
            address="Kayhan Çarşısı, Osmangazi/Bursa",
            sourceLabel="Rota Bursa • Bursa Büyükşehir Belediyesi",
            sourceUrl="https://rota.bursa.com.tr/mekanlar/yeni-hacibey-kebapcisi-1970-kayhan-carsisi-782"
        ),

        // -----------------------------------------------------------
        // BURSA — ANTİK
        // -----------------------------------------------------------
        VerifiedPlace(
            id="bursa-antik-iznik-roma-tiyatrosu",
            canonicalId="iznik-roma-tiyatrosu",
            province="Bursa",
            district="İznik",
            section="Antik",
            name="İznik Roma Tiyatrosu",
            featured=true,
            summary="Bursa İl Kültür ve Turizm Müdürlüğü tiyatronun Roma döneminde yapıldığını; Bakanlık kaynakları da İmparator Traianus dönemine tarihlendiğini belirtiyor.",
            address="Selçuk Mahallesi, İznik/Bursa",
            sourceLabel="T.C. Kültür ve Turizm Bakanlığı",
            sourceUrl="https://bursa.ktb.gov.tr/TR-70233/muzeler-ve-oren-yerleri.html"
        ),

        // -----------------------------------------------------------
        // BURSA — GİZEM / HALK KÜLTÜRÜ
        // -----------------------------------------------------------
        VerifiedPlace(
            id="bursa-gizem-karagoz-hacivat",
            canonicalId="karagoz-hacivat-kultur",
            province="Bursa",
            district="Osmangazi",
            section="Gizem",
            name="Hacivat – Karagöz / Karagöz Evi Müzesi",
            featured=true,
            summary="Hacivat ve Karagöz Bursa'nın geleneksel gölge oyunu kültürünün iki ana kişisidir. Kültür Portalı, Karagöz Müzesi ile Hacivat-Karagöz Anıtı'nın Çekirge Caddesi'nde karşılıklı bulunduğunu belirtiyor.",
            address="Karagöz Evi Müzesi, Çekirge Caddesi, Osmangazi/Bursa",
            sourceLabel="T.C. Kültür ve Turizm Bakanlığı • Kültür Portalı",
            sourceUrl="https://www.kulturportali.gov.tr/turkiye/bursa/gezilecekyer/karagoz-evi-muzesi"
        ),

        // -----------------------------------------------------------
        // MERSİN / TARSUS — ANTİK
        // -----------------------------------------------------------
        VerifiedPlace(
            id="mersin-tarsus-antik-gozlukule",
            canonicalId="gozlukule-hoyugu",
            province="Mersin",
            district="Tarsus",
            section="Antik",
            name="Gözlükule Höyüğü",
            featured=true,
            summary="Mersin İl Kültür ve Turizm Müdürlüğü Gözlükule'yi Neolitik Çağ'dan itibaren yerleşim görmüş, Tarsus'un en eski arkeolojik merkezlerinden biri olarak tanımlıyor.",
            address="Gözlükule Höyüğü, Tarsus/Mersin",
            sourceLabel="Mersin İl Kültür ve Turizm Müdürlüğü",
            sourceUrl="https://mersin.ktb.gov.tr/TR-73148/tarsus.html"
        ),
        VerifiedPlace(
            id="mersin-tarsus-antik-donuktas",
            canonicalId="donuktas",
            province="Mersin",
            district="Tarsus",
            section="Antik",
            name="Donuktaş",
            summary="Bakanlık kaynağında Tarsus'taki en eski anıtlardan biri olarak anılıyor; kazıların yapının Roma tapınağı olduğunu gösterdiği belirtiliyor.",
            address="Tekke Mahallesi, Tarsus/Mersin",
            sourceLabel="Mersin İl Kültür ve Turizm Müdürlüğü",
            sourceUrl="https://mersin.ktb.gov.tr/TR-73148/tarsus.html"
        ),
        VerifiedPlace(
            id="mersin-tarsus-antik-altindan-gecme",
            canonicalId="altindan-gecme-roma-hamami",
            province="Mersin",
            district="Tarsus",
            section="Antik",
            name="Altından Geçme (Roma Hamamı)",
            summary="Mersin İl Kültür ve Turizm Müdürlüğü bu kalıntıyı Roma İmparatorluk Çağı'ndan kalan bir hamam olarak tanımlıyor ve M.S. 2–3. yüzyıla tarihlendiriyor.",
            address="Eski Cami'nin yaklaşık 50 m kuzeyi, Tarsus/Mersin",
            sourceLabel="Mersin İl Kültür ve Turizm Müdürlüğü",
            sourceUrl="https://mersin.ktb.gov.tr/TR-73148/tarsus.html"
        ),
        VerifiedPlace(
            id="mersin-tarsus-antik-kleopatra-kapisi",
            canonicalId="kleopatra-kapisi",
            province="Mersin",
            district="Tarsus",
            section="Antik",
            name="Kleopatra Kapısı",
            summary="Tarsus surlarının günümüze kalan kapılarından biridir. Bakanlık kaynağı, kapının Deniz Kapısı olarak da bilindiğini ve Kleopatra-Antonius anlatısıyla ilişkilendirildiğini aktarıyor.",
            address="Kleopatra Kapısı, Tarsus/Mersin",
            sourceLabel="Mersin İl Kültür ve Turizm Müdürlüğü",
            sourceUrl="https://mersin.ktb.gov.tr/TR-73148/tarsus.html"
        ),
        VerifiedPlace(
            id="mersin-tarsus-antik-justinianus-koprusu",
            canonicalId="justinianus-bac-koprusu",
            province="Mersin",
            district="Tarsus",
            section="Antik",
            name="Justinianus Köprüsü (Baç Köprüsü)",
            summary="Bakanlık kaynağı Berdan Çayı üzerindeki köprünün Bizans İmparatoru Justinianus döneminde, 6. yüzyılda yaptırıldığını belirtiyor.",
            address="Tarsus doğu girişi, Berdan Çayı, Tarsus/Mersin",
            sourceLabel="Mersin İl Kültür ve Turizm Müdürlüğü",
            sourceUrl="https://mersin.ktb.gov.tr/TR-73148/tarsus.html"
        ),
        VerifiedPlace(
            id="mersin-tarsus-antik-st-paul-kuyusu",
            canonicalId="st-paul-kuyusu",
            province="Mersin",
            district="Tarsus",
            section="Antik",
            name="St. Paul Kuyusu",
            summary="Tarsus merkezindeki kuyu, Bakanlık kaynağında St. Paul'un evinin yeri olarak kabul edilen avluda bulunan ve uzun süredir kutsal sayılan bir yapı olarak anlatılıyor.",
            address="Kızılmurat Mahallesi, Tarsus/Mersin",
            sourceLabel="Mersin İl Kültür ve Turizm Müdürlüğü",
            sourceUrl="https://mersin.ktb.gov.tr/TR-73148/tarsus.html"
        ),

        // -----------------------------------------------------------
        // MERSİN / TARSUS — GİZEM / EFSANE
        // Same physical place has ONE card only.
        // -----------------------------------------------------------
        VerifiedPlace(
            id="mersin-tarsus-gizem-eshab-kehf",
            canonicalId="eshab-kehf-yedi-uyurlar",
            province="Mersin",
            district="Tarsus",
            section="Gizem",
            name="Eshab-ı Kehf / Yedi Uyurlar Mağarası",
            aliases=listOf(
                "Eshabı Kehf Mağarası",
                "Ashâb-ı Keyf Mağarası",
                "Yedi Uyurlar Mağarası",
                "Seven Sleepers"
            ),
            featured=true,
            summary="Kültür Portalı, Tarsus'taki mağarayı Yedi Uyurlar inanışının Anadolu'daki önemli merkezlerinden biri olarak tanımlıyor. Anlatıda tek Tanrı inancı nedeniyle kaçan yedi gencin mağaraya sığındığı ve uzun bir uykuya daldığı aktarılıyor.",
            address="Dedeler Mahallesi, Tarsus/Mersin",
            sourceLabel="T.C. Kültür ve Turizm Bakanlığı • Kültür Portalı",
            sourceUrl="https://www.kulturportali.gov.tr/turkiye/mersin/gezilecekyer/eshab-i-kehf"
        ),
        VerifiedPlace(
            id="mersin-tarsus-gizem-sahmeran-hamami",
            canonicalId="sahmeran-hamami",
            province="Mersin",
            district="Tarsus",
            section="Gizem",
            name="Şahmeran Hamamı (Eski Hamam)",
            summary="Mersin İl Kültür ve Turizm Müdürlüğü, yapının Eski Hamam olarak bilindiğini ve halk inanışında Şahmeran'ın burada öldürüldüğünün, kanının duvarlara sıçradığının anlatıldığını kaydediyor.",
            address="Kızılmurat Mahallesi, Tarsus/Mersin",
            sourceLabel="Mersin İl Kültür ve Turizm Müdürlüğü",
            sourceUrl="https://mersin.ktb.gov.tr/TR-73148/tarsus.html"
        ),
        VerifiedPlace(
            id="mersin-tarsus-gizem-donuktas",
            canonicalId="donuktas-efsanesi",
            province="Mersin",
            district="Tarsus",
            section="Gizem",
            name="Donuktaş Efsanesi",
            summary="Bakanlık kaynağında aktarılan halk anlatısına göre Donuktaş'ın bir hükümdar sarayı olduğu ve bir peygamberin darılması üzerine sarayın ters dönerek bugünkü yerine düştüğü söylenir. Kart, anlatıyı efsane olarak açıkça etiketler.",
            address="Donuktaş, Tekke Mahallesi, Tarsus/Mersin",
            sourceLabel="Mersin İl Kültür ve Turizm Müdürlüğü",
            sourceUrl="https://mersin.ktb.gov.tr/TR-73148/tarsus.html"
        ),
        VerifiedPlace(
            id="mersin-tarsus-gizem-danyal",
            canonicalId="danyal-peygamber-makami",
            province="Mersin",
            district="Tarsus",
            section="Gizem",
            name="Danyal Peygamber Makamı Rivayeti",
            summary="Mersin İl Kültür ve Turizm Müdürlüğü, Makam-ı Şerif Camii'ndeki kabirle ilgili olarak Danyal Peygamber'in Tarsus'a gelişi, bolluk getirmesi ve burada defnedilmesine ilişkin rivayeti aktarıyor.",
            address="Makam-ı Şerif Camii, Tarsus/Mersin",
            sourceLabel="Mersin İl Kültür ve Turizm Müdürlüğü",
            sourceUrl="https://mersin.ktb.gov.tr/TR-73148/tarsus.html"
        )
    )

    fun query(
        province:String,
        district:String,
        section:String,
        subcategory:String=""
    ):VerifiedBundle {
        val p=PlaceIdentity.normalize(province)
        val d=PlaceIdentity.normalize(district)
        val rows=all
            .asSequence()
            .filter { PlaceIdentity.normalize(it.province)==p }
            .filter { section==it.section }
            .filter { subcategory.isBlank() || it.subcategory==subcategory }
            .filter {
                d.isBlank() || PlaceIdentity.normalize(it.district)==d
            }
            .distinctBy { "${it.section}|${it.subcategory}|${it.canonicalId}" }
            .toList()

        val clean=if(section=="Lezzet") {
            rows.filterNot { row ->
                val n=PlaceIdentity.normalize(row.name)
                forbiddenFoodNames.any { PlaceIdentity.normalize(it) in n }
            }
        } else rows

        val featured=clean
            .filter { it.featured }
            .sortedWith(compareBy<VerifiedPlace> { it.foundedYear ?: Int.MAX_VALUE }.thenBy { it.name })
            .firstOrNull()
            ?: clean.sortedWith(compareBy<VerifiedPlace> { it.foundedYear ?: Int.MAX_VALUE }.thenBy { it.name }).firstOrNull()

        val alternatives=clean
            .filter { featured==null || it.id!=featured.id }
            .sortedWith(compareBy<VerifiedPlace> { it.foundedYear ?: Int.MAX_VALUE }.thenBy { it.name })
            .take(6)

        return VerifiedBundle(featured,alternatives)
    }

    fun dataIssues():List<String> {
        val issues=mutableListOf<String>()

        val duplicateIds=all.groupBy { it.id }.filterValues { it.size>1 }.keys
        duplicateIds.forEach { issues += "duplicate_id:$it" }

        val duplicateCanon=all.groupBy {
            "${PlaceIdentity.normalize(it.province)}|${PlaceIdentity.normalize(it.district)}|${it.section}|${it.subcategory}|${it.canonicalId}"
        }.filterValues { it.size>1 }.keys
        duplicateCanon.forEach { issues += "duplicate_canonical:$it" }

        all.filter { it.sourceLabel.isBlank() || it.sourceUrl.isBlank() }
            .forEach { issues += "missing_source:${it.id}" }

        all.filter { it.address.isBlank() }
            .forEach { issues += "missing_address:${it.id}" }

        all.filter { it.section=="Lezzet" }.forEach { row ->
            val n=PlaceIdentity.normalize(row.name)
            if(forbiddenFoodNames.any { PlaceIdentity.normalize(it) in n }) {
                issues += "forbidden_food:${row.id}"
            }
        }

        val tarsusEshab=all.filter {
            it.province=="Mersin" && it.district=="Tarsus" &&
            it.section=="Gizem" && it.canonicalId=="eshab-kehf-yedi-uyurlar"
        }
        if(tarsusEshab.size!=1) issues += "eshab_card_count:${tarsusEshab.size}"

        return issues
    }
}
