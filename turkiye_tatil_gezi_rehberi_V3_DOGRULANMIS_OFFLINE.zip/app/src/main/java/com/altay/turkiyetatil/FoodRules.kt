package com.altay.turkiyetatil

data class CuratedFood(
    val province:String,
    val district:String="",
    val foodKey:String,
    val nameContains:String,
    val foundedYear:Int,
    val sourceLabel:String,
    val sourceUrl:String
)

object FoodRules {
    val categories = listOf(
        "Köfte","Kebap","Ciğer","Sulu Yemek",
        "Esnaf Lokantası","Balık","Kahvaltı","Tavuk"
    )

    private val chainTokens = listOf(
        "burger king","mcdonald","kfc","popeyes","domino","pizza hut",
        "starbucks","subway","arby's","arbys","little caesars","sbarro",
        "köfteci yusuf","kofteci yusuf","baydöner","baydoner","hd iskender",
        "tavuk dünyası","tavuk dunyasi","usta dönerci","usta donerci","pidem"
    )

    private val curated = listOf(
        CuratedFood(
            province="Bursa",
            district="İnegöl",
            foodKey="Köfte",
            nameContains="besler",
            foundedYear=1893,
            sourceLabel="Rota Bursa",
            sourceUrl="https://rota.bursa.com.tr/mekanlar/besler-inegol-koftecisi-1893-776"
        ),
        CuratedFood(
            province="Bursa",
            district="",
            foodKey="Köfte",
            nameContains="rodop",
            foundedYear=1946,
            sourceLabel="Rodop Köftecisi tarihçe",
            sourceUrl="https://rodopkoftecisi.com.tr/tarihce/"
        )
    )

    fun isChain(name:String, brand:String="", operator:String=""):Boolean {
        val text=PlaceIdentity.normalize("$name $brand $operator")
        return chainTokens.any { PlaceIdentity.normalize(it) in text }
    }

    fun curatedMatch(
        province:String,
        district:String,
        foodKey:String,
        name:String
    ):CuratedFood? {
        val p=PlaceIdentity.normalize(province)
        val d=PlaceIdentity.normalize(district)
        val n=PlaceIdentity.normalize(name)
        return curated
            .filter {
                PlaceIdentity.normalize(it.province)==p &&
                it.foodKey==foodKey &&
                (it.district.isBlank() || d.isBlank() || PlaceIdentity.normalize(it.district)==d) &&
                PlaceIdentity.normalize(it.nameContains) in n
            }
            .minByOrNull { it.foundedYear }
    }

    fun parseStartYear(raw:String):Int? {
        val m=Regex("""\b(18|19|20)\d{2}\b""").find(raw)?.value ?: return null
        val y=m.toIntOrNull() ?: return null
        return if(y in 1800..2100) y else null
    }

    fun nameMatches(foodKey:String,name:String,cuisine:String=""):Boolean {
        val n=PlaceIdentity.normalize("$name $cuisine")
        val tokens=when(foodKey) {
            "Köfte" -> listOf("kofte","kofteci","meatball")
            "Kebap" -> listOf("kebap","kebab","ocakbasi","doner")
            "Ciğer" -> listOf("ciger","arnavut ciger")
            "Sulu Yemek" -> listOf("sulu yemek","ev yemek","ev yemekleri","tabldot")
            "Esnaf Lokantası" -> listOf("esnaf lokantasi","lokanta","sofra")
            "Balık" -> listOf("balik","balikci","seafood","fish")
            "Kahvaltı" -> listOf("kahvalti","breakfast","serpme")
            "Tavuk" -> listOf("tavuk","pilic","chicken")
            else -> emptyList()
        }
        return tokens.any { PlaceIdentity.normalize(it) in n }
    }
}
