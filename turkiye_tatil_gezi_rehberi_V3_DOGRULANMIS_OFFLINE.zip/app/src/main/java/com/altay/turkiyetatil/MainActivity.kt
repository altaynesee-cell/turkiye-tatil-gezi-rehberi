package com.altay.turkiyetatil

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.net.URLEncoder

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { VerifiedApp(this) } }
    }
}

@Composable
private fun VerifiedApp(activity:ComponentActivity) {
    var province by remember { mutableStateOf("Bursa") }
    var district by remember { mutableStateOf("") }
    var provinceMenu by remember { mutableStateOf(false) }
    var section by remember { mutableStateOf("Lezzet") }
    var foodKey by remember { mutableStateOf("Köfte") }

    fun currentBundle():VerifiedBundle =
        VerifiedCatalog.query(
            province=province,
            district=district,
            section=section,
            subcategory=if(section=="Lezzet") foodKey else ""
        )

    val bundle=currentBundle()
    val count=(if(bundle.featured!=null) 1 else 0)+bundle.alternatives.size

    fun route(place:VerifiedPlace) {
        val q=URLEncoder.encode("${place.name}, ${place.address}","UTF-8")
        val uri=Uri.parse("geo:0,0?q=$q")
        activity.startActivity(Intent(Intent.ACTION_VIEW,uri))
    }

    Surface(Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize().padding(horizontal=14.dp, vertical=10.dp),
            verticalArrangement=Arrangement.spacedBy(9.dp)
        ) {
            Text("Türkiye Tatil Gezi Rehberi",fontSize=25.sp,fontWeight=FontWeight.Bold)
            Text("V3 • Doğrulanmış offline",fontWeight=FontWeight.SemiBold)
            Text(
                "Lezzet, Antik ve Gizem canlı internet taraması yapmaz. " +
                "Yalnız kaynaklı kayıt gösterir.",
                style=MaterialTheme.typography.bodySmall
            )

            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                Box(Modifier.weight(1f)) {
                    OutlinedButton(
                        onClick={provinceMenu=true},
                        modifier=Modifier.fillMaxWidth()
                    ) { Text("📍 $province") }

                    DropdownMenu(
                        expanded=provinceMenu,
                        onDismissRequest={provinceMenu=false}
                    ) {
                        Provinces.all.forEach { p ->
                            DropdownMenuItem(
                                text={Text(p)},
                                onClick={
                                    province=p
                                    district=""
                                    provinceMenu=false
                                }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value=district,
                    onValueChange={district=it},
                    label={Text("İlçe (isteğe bağlı)")},
                    singleLine=true,
                    modifier=Modifier.weight(1f)
                )
            }

            Row(horizontalArrangement=Arrangement.spacedBy(6.dp),modifier=Modifier.fillMaxWidth()) {
                listOf("Lezzet","Antik","Gizem").forEach { item ->
                    if(section==item) {
                        Button(onClick={section=item},modifier=Modifier.weight(1f)) { Text(item) }
                    } else {
                        OutlinedButton(onClick={section=item},modifier=Modifier.weight(1f)) { Text(item) }
                    }
                }
            }

            if(section=="Lezzet") {
                Text("Yöresel / köklü lezzet",fontWeight=FontWeight.Bold)
                VerifiedCatalog.foodCategories.chunked(2).forEach { row ->
                    Row(horizontalArrangement=Arrangement.spacedBy(6.dp),modifier=Modifier.fillMaxWidth()) {
                        row.forEach { key ->
                            if(foodKey==key) {
                                Button(onClick={foodKey=key},modifier=Modifier.weight(1f)) { Text(key) }
                            } else {
                                OutlinedButton(onClick={foodKey=key},modifier=Modifier.weight(1f)) { Text(key) }
                            }
                        }
                    }
                }
            }

            val message=when {
                count>0 && section=="Lezzet" ->
                    "$count doğrulanmış kayıt • Ana öneri 1, kalanlar alternatif."
                count>0 ->
                    "$count doğrulanmış ve kaynaklı kayıt."
                section=="Lezzet" ->
                    "Bu bölge ve lezzet türü için doğrulanmış kayıt henüz yok. Yanlış yer göstermiyorum."
                else ->
                    "Bu bölge için doğrulanmış $section kaydı henüz yok. Yanlış yer göstermiyorum."
            }

            Card(shape=RoundedCornerShape(16.dp),modifier=Modifier.fillMaxWidth()) {
                Text(message,modifier=Modifier.padding(12.dp),fontWeight=FontWeight.SemiBold)
            }

            LazyColumn(
                modifier=Modifier.weight(1f),
                verticalArrangement=Arrangement.spacedBy(10.dp)
            ) {
                bundle.featured?.let { p ->
                    item(key="featured-${p.id}") {
                        Card(shape=RoundedCornerShape(18.dp),modifier=Modifier.fillMaxWidth()) {
                            Column(
                                Modifier.padding(15.dp),
                                verticalArrangement=Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    if(section=="Lezzet") "⭐ KÖKLÜ / MEŞHUR ANA ÖNERİ"
                                    else "⭐ ÖNE ÇIKAN DOĞRULANMIŞ YER",
                                    fontWeight=FontWeight.Bold
                                )
                                Text(p.name,fontSize=21.sp,fontWeight=FontWeight.Bold)
                                Text("${p.district}, ${p.province}")
                                p.foundedYear?.let {
                                    Text("🕰 Kuruluş: $it",fontWeight=FontWeight.SemiBold)
                                }
                                Text(p.summary)
                                Text("Kaynak: ${p.sourceLabel}",style=MaterialTheme.typography.bodySmall)
                                Button(
                                    onClick={route(p)},
                                    modifier=Modifier.fillMaxWidth()
                                ) { Text("🧭 YOL TARİFİ") }
                            }
                        }
                    }
                    if(bundle.alternatives.isNotEmpty()) {
                        item {
                            Text(
                                if(section=="Lezzet") "Yerel alternatifler" else "Diğer doğrulanmış yerler",
                                fontWeight=FontWeight.Bold,
                                fontSize=18.sp
                            )
                        }
                    }
                }

                items(bundle.alternatives,key={it.id}) { p ->
                    Card(shape=RoundedCornerShape(18.dp),modifier=Modifier.fillMaxWidth()) {
                        Column(
                            Modifier.padding(15.dp),
                            verticalArrangement=Arrangement.spacedBy(6.dp)
                        ) {
                            Text(p.name,fontSize=19.sp,fontWeight=FontWeight.Bold)
                            Text("${p.district}, ${p.province}")
                            p.foundedYear?.let { Text("🕰 Kuruluş: $it") }
                            Text(p.summary)
                            Text("Kaynak: ${p.sourceLabel}",style=MaterialTheme.typography.bodySmall)
                            Button(
                                onClick={route(p)},
                                modifier=Modifier.fillMaxWidth()
                            ) { Text("🧭 YOL TARİFİ") }
                        }
                    }
                }
            }

            Text(
                "Kural: doğrulanmamış sonuç göstermek yerine boş liste gösterilir.",
                style=MaterialTheme.typography.labelSmall
            )
        }
    }
}
