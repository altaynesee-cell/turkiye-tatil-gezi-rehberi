package com.altay.turkiyetatil

import org.junit.Assert.*
import org.junit.Test

class FoodRulesTest {
    @Test fun zincirlerFiltrelenir() {
        assertTrue(FoodRules.isChain("Burger King"))
        assertTrue(FoodRules.isChain("Köfteci Yusuf"))
        assertTrue(FoodRules.isChain("Tavuk Dünyası"))
        assertFalse(FoodRules.isChain("Rodop Köftecisi"))
    }

    @Test fun kategoriEslesmeleriKesin() {
        assertTrue(FoodRules.nameMatches("Köfte","İnegöl Köftecisi Besler"))
        assertTrue(FoodRules.nameMatches("Ciğer","Ciğerci Ahmet"))
        assertFalse(FoodRules.nameMatches("Ciğer","Aras Kargo Delivery Service"))
        assertFalse(FoodRules.nameMatches("Köfte","Burger King"))
    }

    @Test fun bursaBeslerKokluKaydiVar() {
        val c=FoodRules.curatedMatch("Bursa","","Köfte","İnegöl Köftecisi Besler")
        assertNotNull(c)
        assertEquals(1893,c!!.foundedYear)
    }

    @Test fun kurulusYiliOkunur() {
        assertEquals(1946,FoodRules.parseStartYear("1946"))
        assertEquals(1893,FoodRules.parseStartYear("1893-01-01"))
        assertNull(FoodRules.parseStartYear("eski işletme"))
    }
}
