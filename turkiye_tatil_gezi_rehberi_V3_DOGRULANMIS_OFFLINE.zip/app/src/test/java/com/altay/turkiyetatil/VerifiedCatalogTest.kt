package com.altay.turkiyetatil

import org.junit.Assert.*
import org.junit.Test

class VerifiedCatalogTest {
    @Test fun katalogdaVeriSorunuYok() {
        assertEquals(emptyList<String>(), VerifiedCatalog.dataIssues())
    }

    @Test fun bursaKofteAnaOneriBesler1893() {
        val b=VerifiedCatalog.query("Bursa","","Lezzet","Köfte")
        assertNotNull(b.featured)
        assertEquals("Besler İnegöl Köftecisi", b.featured!!.name)
        assertEquals(1893, b.featured!!.foundedYear)
    }

    @Test fun bursaKofteYusufYok() {
        val b=VerifiedCatalog.query("Bursa","","Lezzet","Köfte")
        val names=(listOfNotNull(b.featured)+b.alternatives)
            .joinToString(" ") { it.name.lowercase() }
        assertFalse(names.contains("yusuf"))
    }

    @Test fun tarsusYediUyurlarTekKart() {
        val b=VerifiedCatalog.query("Mersin","Tarsus","Gizem")
        val rows=listOfNotNull(b.featured)+b.alternatives
        assertEquals(1, rows.count { it.canonicalId=="eshab-kehf-yedi-uyurlar" })
    }

    @Test fun tarsusAntikGercekKaynakliYerlerVar() {
        val b=VerifiedCatalog.query("Mersin","Tarsus","Antik")
        val rows=listOfNotNull(b.featured)+b.alternatives
        assertTrue(rows.any { it.name=="Gözlükule Höyüğü" })
        assertTrue(rows.any { it.name=="Donuktaş" })
        assertTrue(rows.any { it.name=="Kleopatra Kapısı" })
    }

    @Test fun ilceKilidiCalisir() {
        val inegol=VerifiedCatalog.query("Bursa","İnegöl","Lezzet","Köfte")
        val rows=listOfNotNull(inegol.featured)+inegol.alternatives
        assertTrue(rows.isNotEmpty())
        assertTrue(rows.all { it.district=="İnegöl" })
        assertFalse(rows.any { it.name=="Rodop Köftecisi" })
    }

    @Test fun bilinmeyenBolgeUydurmaSonucVermez() {
        val b=VerifiedCatalog.query("Ağrı","","Lezzet","Köfte")
        assertNull(b.featured)
        assertTrue(b.alternatives.isEmpty())
    }

    @Test fun seksenBirIlVar() {
        assertEquals(81, Provinces.all.distinct().size)
    }
}
