# Türkiye Tatil Gezi Rehberi — V3 Doğrulanmış Offline

Bu sürümde kritik üç bölümde canlı web/OSM taraması YOK:

- Lezzet
- Antik
- Gizem / Efsane

Temel kural:
**Doğrulanmamış yer göstermek yerine boş liste göster.**

İlk doğrulama veri paketi özellikle regresyon testleri için:
- Bursa / Köfte
- Bursa / Kebap
- Bursa / Antik
- Bursa / Gizem kültür noktası
- Mersin / Tarsus / Antik
- Mersin / Tarsus / Gizem

Bursa Köfte:
1. Besler İnegöl Köftecisi — 1893 — ana öneri
2. Sefa İnegöl Köftecisi — 1940
3. Rodop Köftecisi — 1946
4. Ömür Köftecisi — 1965

Köfteci Yusuf ve fast-food zincirleri bu doğrulanmış kataloğa alınmaz.

Tarsus Gizem:
- Eshab-ı Kehf / Yedi Uyurlar yalnız TEK kart
- Şahmeran Hamamı
- Donuktaş Efsanesi
- Danyal Peygamber Makamı rivayeti

Her kart:
- kaynak etiketi
- kısa açıklama
- adres
- Yol Tarifi

81 il seçicide bulunur. Bir ilde doğrulanmış kayıt yoksa uygulama
"doğrulanmış kayıt henüz yok" der; internetten rastgele sonuç çekmez.
