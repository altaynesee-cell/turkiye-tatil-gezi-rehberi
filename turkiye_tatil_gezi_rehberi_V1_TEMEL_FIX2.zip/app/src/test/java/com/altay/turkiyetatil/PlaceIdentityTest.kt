package com.altay.turkiyetatil

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Test

class PlaceIdentityTest {
    private fun p(name: String, lat: Double? = null, lon: Double? = null, district: String = "Tarsus") = Place(
        sourceId = name, name = name, province = "Mersin", district = district,
        category = "magara", latitude = lat, longitude = lon
    )

    @Test fun yediUyurlarVeEshabiKehfTekYerdir() {
        val rows = listOf(
            p("Eshab-ı Kehf / Yedi Uyurlar"), p("Eshabı Kehf Mağarası - Mersin"),
            p("Ashâb-ı Keyf Mağarası"), p("Yedi Uyurlar Mağarası")
        )
        assertEquals(1, PlaceIdentity.dedupe(rows).size)
    }

    @Test fun taskuyuTurkceIngilizceTekYerdir() {
        val rows = listOf(
            p("Taşkuyu Mağarası", 36.930000, 34.890000),
            p("Taşkuyu Mağarası - Taskuyu Cave", 36.930050, 34.890030)
        )
        assertEquals(1, PlaceIdentity.dedupe(rows).size)
    }

    @Test fun farkliMagaralarBirlesmez() {
        assertFalse(PlaceIdentity.samePhysicalPlace(p("Taşkuyu Mağarası"), p("Eshab-ı Kehf Mağarası")))
    }

    @Test fun ayniIsimFarkliIlceBirlesmez() {
        assertFalse(PlaceIdentity.samePhysicalPlace(p("Örnek Mağara", district="Tarsus"), p("Örnek Mağara", district="Anamur")))
    }
}
