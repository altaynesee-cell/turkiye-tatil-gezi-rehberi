package com.altay.turkiyetatil

data class Place(
    val sourceId: String,
    val name: String,
    val aliases: List<String> = emptyList(),
    val province: String,
    val district: String,
    val category: String,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val sourceName: String = ""
)
