package com.altay.turkiyetatil

import java.text.Normalizer
import kotlin.math.*

object PlaceIdentity {
    private val noiseWords = setOf(
        "magara", "magarasi", "cave", "entrance", "giris", "girisi",
        "kale", "kalesi", "museum", "muze", "muzesi", "the", "of"
    )

    fun normalize(value: String): String {
        var s = value.lowercase()
            .replace('ı', 'i').replace('ş', 's').replace('ğ', 'g')
            .replace('ü', 'u').replace('ö', 'o').replace('ç', 'c')
        s = Normalizer.normalize(s, Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "")
            .replace(Regex("[^a-z0-9]+"), " ")
            .trim().replace(Regex("\\s+"), " ")
        s = s.replace(Regex("\\b(ashabi|ashab|eshabi|eshab)\\b"), "eshab")
        s = s.replace(Regex("\\b(keyf|kehf|kehfi)\\b"), "kehf")
        s = s.replace(Regex("\\byedi\\s+uyurlar\\b"), "eshab kehf")
        s = s.replace(Regex("\\bseven\\s+sleepers\\b"), "eshab kehf")
        s = s.replace(Regex("\\beshab\\s+i\\s+kehf\\b"), "eshab kehf")
        return s.replace(Regex("\\s+"), " ").trim()
    }

    fun coreName(value: String): String {
        val n = normalize(value)
        if (n.contains("eshab kehf")) return "eshab kehf"
        val seen = linkedSetOf<String>()
        n.split(" ").filter { it.length > 1 && it !in noiseWords }.forEach { seen += it }
        return seen.joinToString(" ")
    }

    fun samePhysicalPlace(a: Place, b: Place): Boolean {
        if (normalize(a.province) != normalize(b.province)) return false
        val ad = normalize(a.district); val bd = normalize(b.district)
        if (ad.isNotBlank() && bd.isNotBlank() && ad != bd) return false
        val aNames = (listOf(a.name) + a.aliases).map(::coreName).filter { it.isNotBlank() }
        val bNames = (listOf(b.name) + b.aliases).map(::coreName).filter { it.isNotBlank() }
        if (aNames.any { x -> bNames.any { y -> sameNameCore(x, y) } }) return true
        val distance = distanceMeters(a.latitude, a.longitude, b.latitude, b.longitude)
        if (distance != null && distance <= 100.0) {
            val best = aNames.maxOfOrNull { x -> bNames.maxOfOrNull { y -> tokenSimilarity(x, y) } ?: 0.0 } ?: 0.0
            if (best >= 0.50) return true
        }
        return false
    }

    fun dedupe(input: List<Place>): List<Place> {
        val out = mutableListOf<Place>()
        for (place in input) if (out.none { samePhysicalPlace(it, place) }) out += place
        return out
    }

    private fun sameNameCore(a: String, b: String): Boolean {
        if (a == b) return true
        if (a.length >= 5 && b.length >= 5 && (a.contains(b) || b.contains(a))) return true
        return tokenSimilarity(a, b) >= 0.67
    }

    private fun tokenSimilarity(a: String, b: String): Double {
        val aa = a.split(" ").filter { it.length >= 3 }.toSet()
        val bb = b.split(" ").filter { it.length >= 3 }.toSet()
        if (aa.isEmpty() || bb.isEmpty()) return 0.0
        return aa.intersect(bb).size.toDouble() / aa.union(bb).size.toDouble()
    }

    private fun distanceMeters(lat1: Double?, lon1: Double?, lat2: Double?, lon2: Double?): Double? {
        if (lat1 == null || lon1 == null || lat2 == null || lon2 == null) return null
        val r = 6_371_000.0
        val p1 = Math.toRadians(lat1); val p2 = Math.toRadians(lat2)
        val dp = Math.toRadians(lat2 - lat1); val dl = Math.toRadians(lon2 - lon1)
        val h = sin(dp / 2).pow(2) + cos(p1) * cos(p2) * sin(dl / 2).pow(2)
        return 2 * r * asin(sqrt(h))
    }
}
