package com.altay.turkiyetatil

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface(modifier = Modifier.fillMaxSize()) { App() } } }
    }
}

@Composable private fun App() {
    var selected by remember { mutableStateOf("Keşfet") }
    val tabs = listOf("🍽️ Lezzet", "🌊 Deniz", "🏛️ Keşfet", "🛏️ Konak")
    Column(modifier = Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Spacer(Modifier.height(18.dp))
        Text("Türkiye Tatil Gezi Rehberi", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text("V1 • Temiz temel", style = MaterialTheme.typography.titleMedium)
        Card(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Önce doğruluk.", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                Text("Bu ilk sürüm gerçek sonuç göstermiyor. Önce tek yer = tek kart motoru otomatik testlerden geçiyor; Türkiye verisini sonraki adımda bağlayacağız.")
            }
        }
        tabs.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { label ->
                    val name = label.substringAfter(" ")
                    Button(onClick = { selected = name }, modifier = Modifier.weight(1f)) { Text(label) }
                }
            }
        }
        Card(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Seçili bölüm: $selected", fontWeight = FontWeight.Bold)
                Text("Veri motoru henüz bağlı değil.")
            }
        }
        Spacer(Modifier.weight(1f))
        Text("Aşama 1: uygulama iskeleti + kimlik motoru + testler", style = MaterialTheme.typography.bodySmall)
    }
}
