# Türkiye Tatil Gezi Rehberi — V1 Temel

Bu paket bilinçli olarak gerçek gezi verisi içermez. İlk hedef Android iskeleti ve tek yer = tek kart kimlik motorudur. Eski projeden arama kodu taşınmamıştır.
