package com.altay.turkiyetatil

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CategoryQueryTest {
    private val b=BBox(36.0,37.0,34.0,35.0)

    @Test fun lezzetOnlyUsesExactOsmFoodTags() {
        val q=CategoryQuery.overpass("Lezzet",b)
        assertTrue(q.contains("""["amenity"="restaurant"]"""))
        assertTrue(q.contains("""["amenity"="fast_food"]"""))
        assertFalse(q.contains("delivery"))
        assertFalse(q.contains("liver"))
    }

    @Test fun kesfetHasRealPlaceTags() {
        val q=CategoryQuery.overpass("Keşfet",b)
        assertTrue(q.contains("""["natural"="cave_entrance"]"""))
        assertTrue(q.contains("""["historic"]"""))
        assertTrue(q.contains("""["tourism"="museum"]"""))
    }

    @Test fun sorgularYalnizIsimliNoktalariIster() {
        val q=CategoryQuery.overpass("Lezzet",b)
        assertTrue(q.contains("""["name"]"""))
        assertTrue(q.contains("out center tags 60 qt"))
    }

}
