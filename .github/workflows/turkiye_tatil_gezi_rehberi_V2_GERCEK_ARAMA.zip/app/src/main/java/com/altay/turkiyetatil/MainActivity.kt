package com.altay.turkiyetatil

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.net.URLEncoder

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { App(this) } }
    }
}

@Composable
private fun App(activity:ComponentActivity) {
    var province by remember { mutableStateOf("Mersin") }
    var district by remember { mutableStateOf("Tarsus") }
    var menu by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf("Keşfet") }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Bir kategoriye dokun; gerçek yerleri arayalım.") }
    var results by remember { mutableStateOf<List<SearchResult>>(emptyList()) }

    fun doSearch(category:String) {
        if(loading) return
        selected=category
        loading=true
        results=emptyList()
        message="$province ${district.ifBlank { "" }} için aranıyor…"
        Thread {
            try {
                val r=SearchEngine.search(province,district,category)
                activity.runOnUiThread {
                    results=r
                    message=if(r.isEmpty()) "Bu bölgede bu kategori için adlandırılmış sonuç bulunamadı."
                    else "${r.size} tekil sonuç bulundu."
                    loading=false
                }
            } catch(e:Exception) {
                activity.runOnUiThread {
                    message=e.message ?: "Arama sırasında hata oluştu."
                    loading=false
                }
            }
        }.start()
    }

    Surface(Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize().padding(horizontal=16.dp, vertical=12.dp),
            verticalArrangement=Arrangement.spacedBy(10.dp)
        ) {
            Text("Türkiye Tatil Gezi Rehberi",fontSize=27.sp,fontWeight=FontWeight.Bold)
            Text("V2 • Gerçek arama",fontWeight=FontWeight.SemiBold)

            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                Box(Modifier.weight(1f)) {
                    OutlinedButton(onClick={menu=true},modifier=Modifier.fillMaxWidth()) {
                        Text("📍 $province")
                    }
                    DropdownMenu(expanded=menu,onDismissRequest={menu=false}) {
                        Provinces.all.forEach { p ->
                            DropdownMenuItem(
                                text={Text(p)},
                                onClick={ province=p; district=""; menu=false }
                            )
                        }
                    }
                }
                OutlinedTextField(
                    value=district,
                    onValueChange={district=it},
                    label={Text("İlçe (isteğe bağlı)")},
                    singleLine=true,
                    modifier=Modifier.weight(1f)
                )
            }

            Row(horizontalArrangement=Arrangement.spacedBy(7.dp),modifier=Modifier.fillMaxWidth()) {
                listOf("Lezzet" to "🍽️","Deniz" to "🌊").forEach { (cat,ico) ->
                    Button(onClick={doSearch(cat)},modifier=Modifier.weight(1f),enabled=!loading) {
                        Text("$ico $cat")
                    }
                }
            }
            Row(horizontalArrangement=Arrangement.spacedBy(7.dp),modifier=Modifier.fillMaxWidth()) {
                listOf("Keşfet" to "🏛️","Konak" to "🛏️").forEach { (cat,ico) ->
                    Button(onClick={doSearch(cat)},modifier=Modifier.weight(1f),enabled=!loading) {
                        Text("$ico $cat")
                    }
                }
            }

            if(loading) LinearProgressIndicator(Modifier.fillMaxWidth())
            Text(message,style=MaterialTheme.typography.bodyMedium)

            LazyColumn(
                modifier=Modifier.weight(1f),
                verticalArrangement=Arrangement.spacedBy(10.dp)
            ) {
                items(results,key={it.id}) { r ->
                    Card(shape=RoundedCornerShape(18.dp),modifier=Modifier.fillMaxWidth()) {
                        Column(
                            Modifier.padding(15.dp),
                            verticalArrangement=Arrangement.spacedBy(6.dp)
                        ) {
                            Text(r.name,fontSize=20.sp,fontWeight=FontWeight.Bold)
                            Text("${r.district.ifBlank { r.province }}, ${r.province}")
                            Text(r.detail,fontWeight=FontWeight.SemiBold)
                            Text("Kaynak: ${r.source}",style=MaterialTheme.typography.bodySmall)
                            Button(
                                onClick={
                                    val label=URLEncoder.encode(r.name,"UTF-8")
                                    val uri=Uri.parse("geo:${r.lat},${r.lon}?q=${r.lat},${r.lon}($label)")
                                    activity.startActivity(Intent(Intent.ACTION_VIEW,uri))
                                },
                                modifier=Modifier.fillMaxWidth()
                            ) { Text("🧭 YOL TARİFİ") }
                        }
                    }
                }
            }

            Text("© OpenStreetMap katkıda bulunanlar",style=MaterialTheme.typography.labelSmall)
        }
    }
}
