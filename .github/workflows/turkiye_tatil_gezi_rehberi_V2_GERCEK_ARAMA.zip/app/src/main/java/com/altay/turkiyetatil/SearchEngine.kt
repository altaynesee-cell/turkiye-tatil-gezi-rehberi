package com.altay.turkiyetatil

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap

data class SearchResult(
    val id:String,
    val name:String,
    val province:String,
    val district:String,
    val category:String,
    val detail:String,
    val lat:Double,
    val lon:Double,
    val source:String="OpenStreetMap"
)

data class BBox(val south:Double,val north:Double,val west:Double,val east:Double)

object SearchEngine {
    private const val USER_AGENT = "TurkiyeTatilGeziRehberi/2.0 (personal travel assistant)"
    private val bboxCache = ConcurrentHashMap<String,BBox>()
    @Volatile private var lastNominatimRequestAt=0L

    fun search(province:String,district:String,category:String):List<SearchResult> {
        val box=geocode(province,district)
            ?: throw IllegalStateException("Konum bulunamadı. İl/ilçe adını kontrol et.")

        val query=CategoryQuery.overpass(category,box)
        val body="data="+URLEncoder.encode(query,"UTF-8")
        val con=(URL("https://overpass-api.de/api/interpreter").openConnection() as HttpURLConnection).apply {
            requestMethod="POST"
            connectTimeout=20000
            readTimeout=35000
            doOutput=true
            setRequestProperty("User-Agent",USER_AGENT)
            setRequestProperty("Content-Type","application/x-www-form-urlencoded; charset=UTF-8")
        }
        con.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        if(con.responseCode !in 200..299) {
            throw IllegalStateException("Harita servisi şu an yanıt vermedi (${con.responseCode}).")
        }
        val text=con.inputStream.bufferedReader().use { it.readText() }
        val arr=JSONObject(text).optJSONArray("elements") ?: JSONArray()

        val raw=mutableListOf<Place>()
        val mapped=linkedMapOf<String,SearchResult>()

        for(i in 0 until arr.length()) {
            val e=arr.optJSONObject(i) ?: continue
            val tags=e.optJSONObject("tags") ?: continue
            val name=tags.optString("name").trim()
            if(name.isBlank()) continue

            val type=e.optString("type")
            val osmId=e.optLong("id")
            val center=e.optJSONObject("center")
            val lat=if(e.has("lat")) e.optDouble("lat") else center?.optDouble("lat") ?: Double.NaN
            val lon=if(e.has("lon")) e.optDouble("lon") else center?.optDouble("lon") ?: Double.NaN
            if(lat.isNaN() || lon.isNaN()) continue

            val exactDetail=detailFor(category,tags)
            val id="$type/$osmId"

            val p=Place(
                sourceId=id,
                name=name,
                province=province,
                district=district,
                category=category,
                latitude=lat,
                longitude=lon,
                sourceName="OpenStreetMap"
            )
            raw+=p
            mapped[id]=SearchResult(id,name,province,district,category,exactDetail,lat,lon)
        }

        // Tek fiziksel yer = tek kart. OSM node/way/relation aynı yeri ayrı ayrı taşısa bile filtrelenir.
        return PlaceIdentity.dedupe(raw)
            .mapNotNull { mapped[it.sourceId] }
            .sortedBy { PlaceIdentity.normalize(it.name) }
            .take(40)
    }

    private fun geocode(province:String,district:String):BBox? {
        val key=(district.trim()+"|"+province.trim()).lowercase()
        bboxCache[key]?.let { return it }

        // Nominatim public policy: user-triggered, <=1 request/second, identifiable UA.
        synchronized(this) {
            val wait=1100L-(System.currentTimeMillis()-lastNominatimRequestAt)
            if(wait>0) Thread.sleep(wait)
            lastNominatimRequestAt=System.currentTimeMillis()
        }

        val q=listOf(district.trim(),province.trim(),"Türkiye").filter { it.isNotBlank() }.joinToString(", ")
        val url="https://nominatim.openstreetmap.org/search?format=jsonv2&countrycodes=tr&limit=1&" +
                "q="+URLEncoder.encode(q,"UTF-8")
        val con=(URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod="GET"
            connectTimeout=15000
            readTimeout=20000
            setRequestProperty("User-Agent",USER_AGENT)
            setRequestProperty("Accept-Language","tr")
        }
        if(con.responseCode !in 200..299) return null
        val txt=con.inputStream.bufferedReader().use { it.readText() }
        val arr=JSONArray(txt)
        if(arr.length()==0) return null
        val b=arr.getJSONObject(0).getJSONArray("boundingbox")
        val box=BBox(
            south=b.getString(0).toDouble(),
            north=b.getString(1).toDouble(),
            west=b.getString(2).toDouble(),
            east=b.getString(3).toDouble()
        )
        bboxCache[key]=box
        return box
    }

    private fun detailFor(category:String,tags:JSONObject):String {
        return when(category) {
            "Lezzet" -> listOfNotNull(
                tags.optString("cuisine").takeIf { it.isNotBlank() }?.let { "Mutfak: ${it.replace(';',',')}" },
                tags.optString("amenity").takeIf { it.isNotBlank() }?.let { "Tür: $it" }
            ).joinToString(" • ").ifBlank { "Yeme-içme noktası" }

            "Deniz" -> when {
                tags.optString("natural")=="beach" -> "Plaj"
                tags.optString("leisure")=="beach_resort" -> "Plaj / sahil tesisi"
                tags.optString("natural")=="bay" -> "Koy / körfez"
                else -> "Deniz noktası"
            }

            "Keşfet" -> when {
                tags.optString("natural")=="cave_entrance" -> "Mağara"
                tags.has("historic") -> "Tarihi yer • ${tags.optString("historic")}"
                tags.optString("tourism")=="museum" -> "Müze"
                tags.optString("historic")=="archaeological_site" -> "Arkeolojik alan"
                else -> "Gezilecek yer"
            }

            "Konak" -> "Konaklama • ${tags.optString("tourism")}"
            else -> ""
        }
    }
}

object CategoryQuery {
    fun overpass(category:String,b:BBox):String {
        val bb="${b.south},${b.west},${b.north},${b.east}"
        val parts=when(category) {
            "Lezzet" -> listOf(
                """nwr["amenity"="restaurant"]($bb);""",
                """nwr["amenity"="fast_food"]($bb);""",
                """nwr["amenity"="cafe"]($bb);"""
            )
            "Deniz" -> listOf(
                """nwr["natural"="beach"]($bb);""",
                """nwr["leisure"="beach_resort"]($bb);""",
                """nwr["natural"="bay"]($bb);"""
            )
            "Keşfet" -> listOf(
                """nwr["natural"="cave_entrance"]($bb);""",
                """nwr["historic"]($bb);""",
                """nwr["tourism"="museum"]($bb);"""
            )
            "Konak" -> listOf(
                """nwr["tourism"="hotel"]($bb);""",
                """nwr["tourism"="guest_house"]($bb);""",
                """nwr["tourism"="hostel"]($bb);""",
                """nwr["tourism"="motel"]($bb);""",
                """nwr["tourism"="apartment"]($bb);""",
                """nwr["tourism"="camp_site"]($bb);"""
            )
            else -> emptyList()
        }
        return "[out:json][timeout:25];("+parts.joinToString("")+");out center tags 100;"
    }
}
