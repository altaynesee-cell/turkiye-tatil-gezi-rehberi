# Türkiye Tatil Gezi Rehberi — V2 Gerçek Arama

Bu sürüm artık gerçek arama yapar.

- 81 il listesi
- İlçe isteğe bağlı
- Lezzet: OSM amenity=restaurant / fast_food / cafe
- Deniz: natural=beach / bay, leisure=beach_resort
- Keşfet: mağara, historic, müze
- Konak: hotel, guest_house, hostel, motel, apartment, camp_site
- Sonuçlarda Yol Tarifi
- Tek fiziksel yer = tek kart filtresi
- API anahtarı yok
- OpenStreetMap / Nominatim / Overpass kullanır
- İnternet bağlantısı gerekir

Not: Gizem/Efsane bu sürüme bilinçli olarak eklenmedi. O özellik ayrı ve kaynaklı veri motoruyla eklenecek; OSM'den efsane uydurulmayacak.
